module.exports = {
  plugins: [
    require('postcss-nesting'),
    require('@tailwindcss/postcss'),
    require('autoprefixer'),
  ],
}